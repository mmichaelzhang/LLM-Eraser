import random
import numpy as np
import torch

from datasets import load_dataset
import datasets
from torch.utils.data.dataset import Dataset

def get_c4(tokenizer, n_samples, seq_len):
    traindata = load_dataset(
        'allenai/c4', 'allenai--c4', data_files={'train': 'en/c4-train.00000-of-01024.json.gz'}, split='train'
    )
    
    tokenized_samples, history = [], []
    for _ in range(n_samples):
        while True:
            i = random.randint(0, len(traindata) - 1)
            tokenized_sample = tokenizer(traindata[i]['text'], return_tensors='pt')
            if tokenized_sample.input_ids.shape[1] >= seq_len and i not in history:
                history.append(i)
                break
        i = random.randint(0, tokenized_sample.input_ids.shape[1] - seq_len )
        tokenized_samples.append(tokenized_sample.input_ids[:, i:i+seq_len])
    return torch.cat(tokenized_samples, dim=0)

def get_bookcorpus(tokenizer, n_samples, seq_len):
    # traindata = load_dataset(
    #     'bookcorpus', split='train'
    # )
    traindata = datasets.load_from_disk('/home/users/zhangshengming02/.cache/huggingface/datasets/bookcorpus/bookcorpus')
    
    tokenized_samples, history = [], []
    for _ in range(n_samples):
        while True:
            i = random.randint(0, len(traindata) - 1)
            tokenized_sample = tokenizer(traindata[i]['text'], return_tensors='pt')
            if tokenized_sample.input_ids.shape[1] >= seq_len and i not in history:
                history.append(i)
                break
        i = random.randint(0, tokenized_sample.input_ids.shape[1] - seq_len)
        tokenized_samples.append(tokenized_sample.input_ids[:, i:i+seq_len])
    return torch.cat(tokenized_samples, dim=0 )

def get_examples(dataset, tokenizer, n_samples, seq_len = 128, neg_task = None, is_neg = False):
    # if dataset == 'c4':
    #     return get_c4(tokenizer, n_samples, seq_len)
    # elif dataset == 'bookcorpus':
    #     return get_bookcorpus(tokenizer, n_samples, seq_len)
    # else:
    #     raise NotImplementedError
    import json

    tasks = ['headqa_en','arithmetic_3da','openbookqa','piqa','boolq','hellaswag']
    tasks_acc = ['headqa','arithmetic','openbookqa','piqa','boolq','hellaswag']
    neg_task = neg_task.split(',')
    print(neg_task)

    all_datasets = [json.load(open('./datasets/train_results/{}_write_out_info.json'.format(task), 'r')) for task in tasks]
    results = []
    for dataset in all_datasets:
        result = []
        for e in dataset:
            for key in e.keys():
                if (key[:6] == 'prompt' and e[key].split('Answer:')[-1] == e['truth']):
                    result.append(e[key])
                elif (key[:6] == 'prompt' and key[7] == str(e['truth'])):
                    result.append(e[key])
        results.append(result)
    tokenized_samples = []
    if not is_neg:
        for dataset in results:
            if (tasks_acc[results.index(dataset)] in neg_task):
                continue
            for _ in range(n_samples):
                i = random.randint(0, len(dataset) - 1)
                tokenized_samples.append(dataset[i])      
    elif is_neg:
        for dataset in results:
            if (tasks_acc[results.index(dataset)] not in neg_task):
                continue
            for _ in range(n_samples):
                i = random.randint(0, len(dataset) - 1)
                tokenized_samples.append(dataset[i])
    tokenized_samples = tokenizer(tokenized_samples, return_tensors='pt', padding=True).input_ids
    # tokenized_sample = tokenizer(dataset[i], return_tensors='pt', padding = 'max_length', max_length = 256)
    #             tokenized_samples.append(tokenized_sample.input_ids)        
    return tokenized_samples

def get_examples_lang(dataset, tokenizer, n_samples, seq_len = 128, neg_task = None, is_neg = False):
    # if dataset == 'c4':
    #     return get_c4(tokenizer, n_samples, seq_len)
    # elif dataset == 'bookcorpus':
    #     return get_bookcorpus(tokenizer, n_samples, seq_len)
    # else:
    #     raise NotImplementedError
    import json

    tasks = ['code', 'en', 'es', 'zh', 'ar']
    tasks_acc = ['code', 'en', 'es', 'zh', 'ar']

    neg_task = neg_task.split(',')
    print(neg_task)

    all_datasets = [[json.loads(e) for e in open('./datasets/Lang_data/{}.jsonl'.format(task), 'r').readlines()] for task in tasks]
    print([(data[0].keys(), len(data)) for data in all_datasets])
    results = []
    for dataset in all_datasets:
        result = []
        for e in dataset:
            result.append(e['inputs']+e['targets'])
        results.append(result)
    tokenized_samples = []
    if not is_neg:
        for dataset in results:
            if (tasks_acc[results.index(dataset)] in neg_task):
                continue
            for _ in range(n_samples):
                i = random.randint(0, len(dataset) - 1)
                tokenized_samples.append(dataset[i])      
    elif is_neg:
        for dataset in results:
            if (tasks_acc[results.index(dataset)] not in neg_task):
                continue
            for _ in range(n_samples):
                i = random.randint(0, len(dataset) - 1)
                tokenized_samples.append(dataset[i])
    tokenized_samples = tokenizer(tokenized_samples, return_tensors='pt', padding=True, truncation=True, max_length=256).input_ids
    # tokenized_sample = tokenizer(dataset[i], return_tensors='pt', padding = 'max_length', max_length = 256)
    #             tokenized_samples.append(tokenized_sample.input_ids)        
    return tokenized_samples